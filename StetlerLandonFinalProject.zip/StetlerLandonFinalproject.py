from tkinter import *
from tkinter import messagebox

class CatDatabase:
    def __init__(self):
        self.cat_list = []

    def add_cat(self, catinfo):
        self.cat_list.append(catinfo)

    def print_cat_database(self):
        print("*"*40)
        print("My Cat Registration System")
        print("*"*40)
        print('Cat Name', 'Cat ID')
        for i in self.cat_list:
            print(i[0]+','+'{:0>4}'.format(i[1]))

class MyFirstGUI:
    # class definition
    # This is the initialize
    # function for a class.
    # Variables belonging to this class
    # will get created and initialized
    # in this function
    # What is the self parameter?
    # It represents this class itself.
    # By using self.functionname,
    # you can call functions belonging to this class.
    # By using self.variablename,
    # you can create and use variables
    # belonging to this class.
    # It needs to be the first parameter
    # of all the functions in your class

    def __init__(self, root):
        self.id =  StringVar()
        self.name =  StringVar()
        self.database = CatDatabase()
        # Master is the default parent object of all widgets.
        # You can think of it as the window that pops up when you run the GUI code.
        self.master = root
        self.master.title("My Cat Registration System")

        # grid function puts a widget at a certain location
        # return value is none, please do not use it like self.label=Label().grad()
        # it will make self.label=none and you will no longer be able to change the label's content
        self.label = Label(self.master, text="Cat Name: ")
        self.label.grid(row=0, column=0, sticky=E)

        self.catnameentry = Entry(self.master)
        self.catnameentry.grid(row=0, column=1, sticky=E)

        self.lblCatID = Label(self.master, text="Cat ID: ")
        self.lblCatID.grid(row=0, column=2, sticky=E)

        self.txtCatID = Entry(self.master)
        self.txtCatID.grid(row=0, column=3, sticky=E)

        self.submitbutton = Button(self.master, text="Submit name", command=self.submitname)
        self.submitbutton.grid(row=0, column=4, sticky=E)

        self.lblRegisteredName = Label(self.master, text="Registered cat name")
        self.lblRegisteredName.grid(row=1, column=0, sticky=E)

        self.txtRegisteredName = Entry(self.master,text="", textvariable=self.name)
        self.txtRegisteredName.grid(row=1, column=1, sticky=E)
        self.txtRegisteredName['state'] = 'disabled'

        self.lblRegisteredID = Label(self.master, text="Registered ID")
        self.lblRegisteredID.grid(row=1, column=2, sticky=E)

        self.txtRegisteredID = Entry(self.master,text="", textvariable=self.id)
        self.txtRegisteredID.grid(row=1, column=3, sticky=E)
        self.txtRegisteredID['state'] = 'disabled'

        self.btnPrintDatabase = Button(self.master, text="Print database", command=self.printdatabase)
        self.btnPrintDatabase.grid(row=1, column=4, sticky=E)

    def submitname(self):
        if not self.catnameentry.get()=="" and  not self.txtCatID.get()=="":
            self.name.set(self.catnameentry.get())
            self.id.set(self.txtCatID.get())
            self.database.add_cat((self.catnameentry.get(),self.txtCatID.get()))
            print("a cat name submitted:", self.catnameentry.get())

        else:
            messagebox.showerror("INPUT ERROR...", "please enter name/id")

    def printdatabase(self):
        self.database.print_cat_database()


if __name__ == '__main__':
    myTkRoot = Tk()
    my_gui = MyFirstGUI(myTkRoot)
    myTkRoot.mainloop()
